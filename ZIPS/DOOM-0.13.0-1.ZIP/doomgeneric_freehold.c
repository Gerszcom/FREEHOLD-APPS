/* doomgeneric_freehold.c: DOOM (doomgeneric) on FREEHOLD.

   FREEHOLD's platform file for doomgeneric, written for FREEHOLD (it is
   FREEHOLD's, under FREEHOLD's licence; doomgeneric itself is GPL-2.0, and
   so is the program built from both). It uses <freehold.h>:

   - the picture: a graphics mode of at least 640x400, the 640x400 frame
     doomgeneric draws (DOOMGENERIC_RESX/RESY, set in FREEHOLD.RSP: DOOM's
     320x200 doubled) scaled by the largest whole factor that fits and
     centred;
   - the keyboard: key events, each key's press and release as scancode
     set 1 (a DOS game's INT 9), mapped to DOOM's keys;
   - the sound: one 16-bit stereo stream at 22050 Hz, into which this file
     mixes DOOM's sound effects (DMX lumps, 8-bit, 11025 or 22050 Hz) and
     its music: MUS lumps become MIDI (doomgeneric's mus2mid) and play
     through TinySoundFont with a General MIDI SoundFont (SOUNDFONT=, else
     C:\APPS\MUSIC\FLUIDR3.SF3; D-098). Without one, the music module says so
     and plays nothing.
   - time: FREEHOLD's milliseconds since boot.  */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <freehold.h>

#include "doomgeneric.h"
#include "doomkeys.h"
#include "doomtype.h"
#include "i_sound.h"
#include "w_wad.h"
#include "z_zone.h"
#include "deh_str.h"
#include "memio.h"
#include "mus2mid.h"

/* The music libraries in C:\TCC\INCLUDE (D-098). */
#include <stb_vorbis.c>
#define TSF_IMPLEMENTATION
#include <tsf.h>
#define MIDIFILE_IMPLEMENTATION
#include <midifile.h>

/* ------------------------------------------------------------------ */
/* The picture. */

static unsigned int *fb;
static int fb_stride, fb_w, fb_h, scale, off_x, off_y;

static void restore(void)
{
    freehold_sound_close();
    freehold_key_events(0);
    freehold_console_raw(0);
    freehold_video_leave();
}

void DG_Init(void)
{
    if (freehold_video_enter(DOOMGENERIC_RESX, DOOMGENERIC_RESY) != 0) {
        fprintf(stderr, "DOOM: no graphics mode of %dx%d or larger\n",
                DOOMGENERIC_RESX, DOOMGENERIC_RESY);
        exit(1);
    }
    fb = freehold_video_pixels();
    fb_stride = freehold_video_stride();
    fb_w = freehold_video_width();
    fb_h = freehold_video_height();
    scale = fb_w / DOOMGENERIC_RESX;
    if (fb_h / DOOMGENERIC_RESY < scale)
        scale = fb_h / DOOMGENERIC_RESY;
    if (scale < 1)
        scale = 1;
    off_x = (fb_w - DOOMGENERIC_RESX * scale) / 2;
    off_y = (fb_h - DOOMGENERIC_RESY * scale) / 2;
    if (off_x < 0)
        off_x = 0;
    if (off_y < 0)
        off_y = 0;
    memset(fb, 0, (size_t)fb_stride * fb_h * 4);
    freehold_console_raw(1);
    freehold_key_events(1);
    atexit(restore);
}

void DG_DrawFrame(void)
{
    int y, x, k, rows = DOOMGENERIC_RESY, cols = DOOMGENERIC_RESX;
    char junk[64];

    if (rows * scale > fb_h)
        rows = fb_h / scale;
    if (cols * scale > fb_w)
        cols = fb_w / scale;
    for (y = 0; y < rows; y++) {
        const pixel_t *in = DG_ScreenBuffer + (size_t)y * DOOMGENERIC_RESX;
        unsigned int *out = fb + (size_t)(off_y + y * scale) * fb_stride + off_x;
        if (scale == 1) {
            memcpy(out, in, cols * 4);
            continue;
        }
        for (x = 0; x < cols; x++)
            for (k = 0; k < scale; k++)
                out[x * scale + k] = in[x];
        for (k = 1; k < scale; k++)
            memcpy(out + (size_t)k * fb_stride, out, (size_t)cols * scale * 4);
    }
    freehold_video_present(off_x, off_y, cols * scale, rows * scale);
    /* The console's own copy of the keys (raw mode) is not used: drop it,
       so none of it reaches the prompt after DOOM ends. */
    while (freehold_input_read(junk, sizeof junk) > 0)
        ;
}

void DG_SleepMs(uint32_t ms)
{
    freehold_sleep_ms(ms);
}

uint32_t DG_GetTicksMs(void)
{
    return (uint32_t)freehold_ticks_ms();
}

void DG_SetWindowTitle(const char *title)
{
    (void)title;
}

/* ------------------------------------------------------------------ */
/* The keyboard: scancode set 1 to DOOM's keys. */

static unsigned char plain_key(int code)
{
    static const char row[] =
        /* 0x00 */ "\0\0" "1234567890" "-=" "\0\0"
        /* 0x10 */ "qwertyuiop[]" "\0\0" "as"
        /* 0x20 */ "dfghjkl;'`" "\0" "\\zxcv"
        /* 0x30 */ "bnm,./";
    switch (code) {
    case 0x01: return KEY_ESCAPE;
    case 0x0C: return KEY_MINUS;
    case 0x0D: return KEY_EQUALS;
    case 0x0E: return KEY_BACKSPACE;
    case 0x0F: return KEY_TAB;
    case 0x1C: return KEY_ENTER;
    case 0x1D: return KEY_FIRE;            /* Ctrl fires */
    case 0x2A: case 0x36: return KEY_RSHIFT;
    case 0x37: return KEYP_MULTIPLY;
    case 0x38: return KEY_RALT;            /* Alt strafes */
    case 0x39: return KEY_USE;             /* Space opens doors */
    case 0x3A: return KEY_CAPSLOCK;
    case 0x45: return KEY_NUMLOCK;
    case 0x46: return KEY_SCRLCK;
    case 0x47: return KEYP_7;
    case 0x48: return KEYP_8;
    case 0x49: return KEYP_9;
    case 0x4A: return KEYP_MINUS;
    case 0x4B: return KEYP_4;
    case 0x4C: return KEYP_5;
    case 0x4D: return KEYP_6;
    case 0x4E: return KEYP_PLUS;
    case 0x4F: return KEYP_1;
    case 0x50: return KEYP_2;
    case 0x51: return KEYP_3;
    case 0x52: return KEYP_0;
    case 0x57: return KEY_F11;
    case 0x58: return KEY_F12;
    }
    if (code >= 0x3B && code <= 0x44)
        return 0x80 + code;                /* F1..F10 */
    if (code < (int)sizeof row - 1)
        return (unsigned char)row[code];
    return 0;
}

static unsigned char extended_key(int code)
{
    switch (code) {
    case 0x1C: return KEY_ENTER;           /* keypad Enter */
    case 0x1D: return KEY_FIRE;            /* right Ctrl */
    case 0x35: return KEYP_DIVIDE;
    case 0x38: return KEY_RALT;
    case 0x47: return KEY_HOME;
    case 0x48: return KEY_UPARROW;
    case 0x49: return KEY_PGUP;
    case 0x4B: return KEY_LEFTARROW;
    case 0x4D: return KEY_RIGHTARROW;
    case 0x4F: return KEY_END;
    case 0x50: return KEY_DOWNARROW;
    case 0x51: return KEY_PGDN;
    case 0x52: return KEY_INS;
    case 0x53: return KEY_DEL;
    }
    return 0;
}

int DG_GetKey(int *pressed, unsigned char *key)
{
    int e;
    while ((e = freehold_key_event()) != 0) {
        int code = e & 0x7F;
        unsigned char k = (e & 0xE000) == 0xE000 ? extended_key(code) : plain_key(code);
        if (k == 0)
            continue;
        *pressed = (e & 0x80) == 0;
        *key = k;
        return 1;
    }
    return 0;
}

int main(int argc, char **argv)
{
    doomgeneric_Create(argc, argv);
    for (;;)
        doomgeneric_Tick();
    return 0;
}

/* ------------------------------------------------------------------ */
/* The stream: sound effects and music, mixed here. Either module opens it
   (DOOM's -nosfx and -nomusic leave one out), and each keeps it full. */

#define MIX_RATE 22050
#define CHANNELS 16
/* How far ahead of the clock the stream is kept full. */
#define LEAD_MS 80
#define BLOCK 64                /* frames the synthesizer renders at once */

struct voice {
    const unsigned char *data;  /* 8-bit unsigned samples */
    unsigned int frames;        /* in the lump's rate */
    unsigned int pos;           /* 16.16, in the lump's rate */
    unsigned int step;          /* 16.16 per output frame */
    int left, right;            /* gains, 0..256 */
    sfxinfo_t *sfx;
    int playing;
};

/* Configuration variables i_sound.c binds (the SDL module's resampler,
   not used here: the kernel's mixer resamples). */
int use_libsamplerate = 0;
float libsamplerate_scale = 0.65f;

static struct voice voices[CHANNELS];
static boolean sfx_on, sfx_prefix;
static int stream_users;
static unsigned long long started_ms, frames_out;
static short mixbuf[4096 * 2];

/* The music (below). */
struct song {
    midi_event *events;
};
static tsf *synth;
static struct song *playing_song;
static midi_event *next_event;
static double song_ms;
static boolean music_on, song_looping, music_paused;
static float music_block[BLOCK * 2];
static int music_left;          /* frames of music_block not yet mixed */
static void music_render(void);

static boolean stream_open(void)
{
    if (stream_users) {
        stream_users++;
        return true;
    }
    if (freehold_sound_open(MIX_RATE, 2) != 0)
        return false;
    started_ms = freehold_ticks_ms();
    frames_out = 0;
    stream_users = 1;
    return true;
}

static void stream_close(void)
{
    if (stream_users && --stream_users == 0)
        freehold_sound_close();
}

static void set_params(struct voice *v, int vol, int sep)
{
    if (vol < 0)
        vol = 0;
    if (vol > 127)
        vol = 127;
    if (sep < 0)
        sep = 0;
    if (sep > 254)
        sep = 254;
    v->left = (254 - sep) * vol / 127;
    v->right = sep * vol / 127;
}

static void mix(int frames)
{
    int i, f;
    for (f = 0; f < frames; f++) {
        int l = 0, r = 0;
        for (i = 0; i < CHANNELS; i++) {
            struct voice *v = &voices[i];
            int s;
            if (!v->playing)
                continue;
            if ((v->pos >> 16) >= v->frames) {
                v->playing = 0;
                continue;
            }
            s = ((int)v->data[v->pos >> 16] - 128) << 8;
            l += s * v->left >> 8;
            r += s * v->right >> 8;
            v->pos += v->step;
        }
        if (music_on && playing_song && !music_paused) {
            if (!music_left)
                music_render();
            l += (int)(music_block[(BLOCK - music_left) * 2] * 32767.0f);
            r += (int)(music_block[(BLOCK - music_left) * 2 + 1] * 32767.0f);
            music_left--;
        }
        /* Several loud sounds at once: halve rather than clip. */
        l >>= 1;
        r >>= 1;
        if (l > 32767) l = 32767;
        if (l < -32768) l = -32768;
        if (r > 32767) r = 32767;
        if (r < -32768) r = -32768;
        mixbuf[f * 2] = (short)l;
        mixbuf[f * 2 + 1] = (short)r;
    }
}

static void stream_pump(void)
{
    unsigned long long now, due, want;
    if (!stream_users)
        return;
    now = freehold_ticks_ms();
    due = (now - started_ms) * MIX_RATE / 1000;
    if (frames_out < due)
        frames_out = due;           /* fell behind: skip, do not catch up */
    want = due + (unsigned long long)LEAD_MS * MIX_RATE / 1000;
    while (frames_out < want) {
        int n = (int)(want - frames_out);
        if (n > 4096)
            n = 4096;
        mix(n);
        if (freehold_sound_write(mixbuf, n * 4) < 0) {
            stream_users = 0;
            sfx_on = music_on = false;
            return;
        }
        frames_out += n;
    }
}

/* ------------------------------------------------------------------ */
/* Sound effects. */

static boolean snd_init(boolean use_sfx_prefix)
{
    int i;
    sfx_prefix = use_sfx_prefix;
    for (i = 0; i < CHANNELS; i++)
        voices[i].playing = 0;
    if (!stream_open()) {
        printf("I_InitSound: no sound device; DOOM plays silently\n");
        return false;
    }
    sfx_on = true;
    printf("I_InitSound: sound effects at %d Hz\n", MIX_RATE);
    return true;
}

static void snd_shutdown(void)
{
    if (sfx_on)
        stream_close();
    sfx_on = false;
}

static int snd_lump(sfxinfo_t *sfx)
{
    char name[9];
    if (sfx->link != NULL)
        sfx = sfx->link;
    if (sfx_prefix)
        snprintf(name, sizeof name, "ds%s", DEH_String(sfx->name));
    else
        snprintf(name, sizeof name, "%s", DEH_String(sfx->name));
    return W_GetNumForName(name);
}

static void snd_update(void)
{
    stream_pump();
}

static void snd_params(int channel, int vol, int sep)
{
    if (channel >= 0 && channel < CHANNELS)
        set_params(&voices[channel], vol, sep);
}

static int snd_start(sfxinfo_t *sfx, int channel, int vol, int sep)
{
    struct voice *v;
    const unsigned char *lump;
    int len;
    unsigned int rate, frames;

    if (!sfx_on || channel < 0 || channel >= CHANNELS)
        return -1;
    v = &voices[channel];
    v->playing = 0;
    lump = W_CacheLumpNum(sfx->lumpnum, PU_STATIC);
    len = W_LumpLength(sfx->lumpnum);
    /* A DMX sound: format 3, the rate, the sample count, then the samples
       with 16 bytes of padding at each end. */
    if (len < 8 || lump[0] != 3 || lump[1] != 0)
        return -1;
    rate = lump[2] | (lump[3] << 8);
    frames = lump[4] | (lump[5] << 8) | (lump[6] << 16) | ((unsigned int)lump[7] << 24);
    if (frames > (unsigned int)len - 8 || frames <= 48 || rate == 0)
        return -1;
    v->data = lump + 8 + 16;
    v->frames = frames - 32;
    v->pos = 0;
    v->step = (unsigned int)(((unsigned long long)rate << 16) / MIX_RATE);
    v->sfx = sfx;
    set_params(v, vol, sep);
    v->playing = 1;
    return channel;
}

static void snd_stop(int channel)
{
    if (channel >= 0 && channel < CHANNELS)
        voices[channel].playing = 0;
}

static boolean snd_playing(int channel)
{
    if (channel < 0 || channel >= CHANNELS)
        return false;
    return voices[channel].playing ? true : false;
}

static void snd_cache(sfxinfo_t *sounds, int n)
{
    (void)sounds;
    (void)n;
}

static snddevice_t sound_devices[] = {
    SNDDEVICE_SB, SNDDEVICE_PAS, SNDDEVICE_GUS,
    SNDDEVICE_WAVEBLASTER, SNDDEVICE_SOUNDCANVAS, SNDDEVICE_AWE32,
};

sound_module_t DG_sound_module = {
    sound_devices,
    sizeof sound_devices / sizeof sound_devices[0],
    snd_init,
    snd_shutdown,
    snd_lump,
    snd_update,
    snd_params,
    snd_start,
    snd_stop,
    snd_playing,
    snd_cache,
};

/* ------------------------------------------------------------------ */
/* Music: MIDI through TinySoundFont. */

#define DEFAULT_SOUNDFONT "C:\\APPS\\MUSIC\\FLUIDR3.SF3"

static void send_event(const midi_event *m)
{
    switch (m->type) {
    case MIDI_PROGRAM_CHANGE: tsf_channel_set_presetnumber(synth, m->channel, m->key, m->channel == 9); break;
    case MIDI_NOTE_ON: tsf_channel_note_on(synth, m->channel, m->key, m->velocity / 127.0f); break;
    case MIDI_NOTE_OFF: tsf_channel_note_off(synth, m->channel, m->key); break;
    case MIDI_PITCH_BEND: tsf_channel_set_pitchwheel(synth, m->channel, m->pitch_bend); break;
    case MIDI_CONTROL_CHANGE: tsf_channel_midi_control(synth, m->channel, m->key, m->velocity); break;
    default: break;
    }
}

/* The next BLOCK frames of music into music_block. */
static void music_render(void)
{
    for (; next_event && next_event->time <= song_ms; next_event = next_event->next)
        send_event(next_event);
    if (!next_event && song_looping && playing_song->events) {
        next_event = playing_song->events;
        song_ms = 0;
    }
    tsf_render_float(synth, music_block, BLOCK, 0);
    song_ms += BLOCK * 1000.0 / MIX_RATE;
    music_left = BLOCK;
}

static boolean mus_init(void)
{
    const char *font = getenv("SOUNDFONT");
    if (!font || !*font)
        font = DEFAULT_SOUNDFONT;
    synth = tsf_load_filename(font);
    if (!synth) {
        printf("I_InitMusic: no SoundFont at %s (SET SOUNDFONT= names one); music is not played\n", font);
        return false;
    }
    if (!stream_open()) {
        printf("I_InitMusic: no sound device; music is not played\n");
        tsf_close(synth);
        synth = NULL;
        return false;
    }
    tsf_set_output(synth, TSF_STEREO_INTERLEAVED, MIX_RATE, 0.0f);
    tsf_set_max_voices(synth, 64);
    tsf_channel_set_bank_preset(synth, 9, 128, 0);
    music_on = true;
    printf("I_InitMusic: General MIDI through the SoundFont %s\n", font);
    return true;
}

static void mus_shutdown(void)
{
    if (!music_on)
        return;
    music_on = false;
    playing_song = NULL;
    tsf_close(synth);
    synth = NULL;
    stream_close();
}

static void mus_volume(int volume)
{
    if (synth)
        tsf_set_volume(synth, volume / 127.0f);
}

static void mus_pause(void) { music_paused = true; }
static void mus_resume(void) { music_paused = false; }

static void *mus_register(void *data, int len)
{
    struct song *song;
    void *midi = data;
    size_t midi_len = (size_t)len;
    MEMFILE *in = NULL, *out = NULL;
    midi_event *e;

    if (!music_on)
        return NULL;
    if (len >= 4 && !memcmp(data, "MUS\x1a", 4)) {
        in = mem_fopen_read(data, (size_t)len);
        out = mem_fopen_write();
        if (mus2mid(in, out)) {     /* true when it fails */
            mem_fclose(in);
            mem_fclose(out);
            return NULL;
        }
        mem_get_buf(out, &midi, &midi_len);
    }
    song = malloc(sizeof *song);
    if (song)
        song->events = midi_load_memory(midi, midi_len);
    if (in) {
        mem_fclose(in);
        mem_fclose(out);
    }
    if (!song || !song->events) {
        free(song);
        return NULL;
    }
    /* Decode the song's instruments now, not at their first notes. */
    for (e = song->events; e; e = e->next) {
        if (e->type == MIDI_PROGRAM_CHANGE)
            tsf_channel_set_presetnumber(synth, e->channel, e->key, e->channel == 9);
        else if (e->type == MIDI_NOTE_ON)
            tsf_preload(synth, tsf_channel_get_preset_index(synth, e->channel), e->key, e->velocity / 127.0f);
    }
    tsf_reset(synth);
    tsf_channel_set_bank_preset(synth, 9, 128, 0);
    return song;
}

static void mus_stop(void)
{
    if (!music_on)
        return;
    playing_song = NULL;
    next_event = NULL;
    tsf_reset(synth);
    tsf_channel_set_bank_preset(synth, 9, 128, 0);
}

static void mus_unregister(void *handle)
{
    struct song *song = handle;
    if (!song)
        return;
    if (playing_song == song)
        mus_stop();
    midi_free(song->events);
    free(song);
    if (synth)
        tsf_release_samples(synth);
}

static void mus_play(void *handle, boolean looping)
{
    if (!music_on || !handle)
        return;
    mus_stop();
    playing_song = handle;
    next_event = playing_song->events;
    song_ms = 0;
    song_looping = looping;
    music_left = 0;
}

static boolean mus_playing(void)
{
    return playing_song != NULL && (next_event != NULL || song_looping || tsf_active_voice_count(synth) > 0);
}

static void mus_poll(void)
{
    stream_pump();
}

music_module_t DG_music_module = {
    sound_devices,
    sizeof sound_devices / sizeof sound_devices[0],
    mus_init,
    mus_shutdown,
    mus_volume,
    mus_pause,
    mus_resume,
    mus_register,
    mus_unregister,
    mus_play,
    mus_stop,
    mus_playing,
    mus_poll,
};
