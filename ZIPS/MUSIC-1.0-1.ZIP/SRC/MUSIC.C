/* MUSIC: play WAV, FLAC, MP3, Ogg Vorbis and MIDI files (D-098).

   FREEHOLD's own program, on the music libraries in C:\TCC\INCLUDE:
   dr_wav, dr_flac and dr_mp3 (public domain or MIT-0), stb_vorbis (public
   domain or MIT), TinySoundFont (MIT) and FREEHOLD's midifile.h. MIDI files play
   through a SoundFont: SOUNDFONT= names one, else C:\APPS\MUSIC\FLUIDR3.SF3.

   Built on FREEHOLD with:  C:\TCC\TCC -o MUSIC.EXE C:\SRC\MUSIC\MUSIC.C */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <freehold.h>

#define DR_WAV_IMPLEMENTATION
#include <dr_wav.h>
#define DR_FLAC_IMPLEMENTATION
#include <dr_flac.h>
#define DR_MP3_IMPLEMENTATION
#include <dr_mp3.h>
#include <stb_vorbis.c>
#define TSF_IMPLEMENTATION
#include <tsf.h>
#define MIDIFILE_IMPLEMENTATION
#include <midifile.h>

#define DEFAULT_SOUNDFONT "C:\\APPS\\MUSIC\\FLUIDR3.SF3"
#define CHUNK 4096          /* frames a write */
#define MIDI_RATE 44100
#define MIDI_TAIL_MS 3000   /* the longest a release may ring after the end */

enum format { UNKNOWN, WAV, FLAC, MP3, VORBIS, MIDI };
static const char *format_name[] = { "?", "WAV", "FLAC", "MP3", "Ogg Vorbis", "MIDI" };

/* A decoder: fills `out` with up to `frames` interleaved 16-bit frames of
   `channels` channels and returns how many it wrote (0 at the end). */
struct source {
    enum format format;
    unsigned rate, channels;
    unsigned long long frames;  /* the length, for the report */
    void *state;
    size_t (*read)(struct source *s, short *out, size_t frames);
    void (*close)(struct source *s);
};

static const char *base_name(const char *path)
{
    const char *b = path, *p;
    for (p = path; *p; p++)
        if (*p == '\\' || *p == '/' || *p == ':')
            b = p + 1;
    return b;
}

static enum format sniff(const char *path)
{
    unsigned char h[12] = { 0 };
    const char *dot;
    FILE *f = fopen(path, "rb");
    if (f) {
        size_t n = fread(h, 1, sizeof h, f);
        fclose(f);
        if (n >= 12 && !memcmp(h, "RIFF", 4) && !memcmp(h + 8, "WAVE", 4)) return WAV;
        if (n >= 4 && !memcmp(h, "fLaC", 4)) return FLAC;
        if (n >= 4 && !memcmp(h, "OggS", 4)) return VORBIS;
        if (n >= 4 && !memcmp(h, "MThd", 4)) return MIDI;
        if (n >= 3 && !memcmp(h, "ID3", 3)) return MP3;
        if (n >= 2 && h[0] == 0xFF && (h[1] & 0xE0) == 0xE0) return MP3;
    }
    dot = strrchr(path, '.');
    if (dot) {
        if (!stricmp(dot, ".wav")) return WAV;
        if (!stricmp(dot, ".flac") || !stricmp(dot, ".fla")) return FLAC;
        if (!stricmp(dot, ".mp3")) return MP3;
        if (!stricmp(dot, ".ogg")) return VORBIS;
        if (!stricmp(dot, ".mid") || !stricmp(dot, ".midi")) return MIDI;
    }
    return UNKNOWN;
}

/* --- Sampled formats --------------------------------------------------- */

static size_t wav_read(struct source *s, short *out, size_t n) { return (size_t)drwav_read_pcm_frames_s16(s->state, n, out); }
static void wav_close(struct source *s) { drwav_uninit(s->state); free(s->state); }
static size_t flac_read(struct source *s, short *out, size_t n) { return (size_t)drflac_read_pcm_frames_s16(s->state, n, out); }
static void flac_close(struct source *s) { drflac_close(s->state); }
static size_t mp3_read(struct source *s, short *out, size_t n) { return (size_t)drmp3_read_pcm_frames_s16(s->state, n, out); }
static void mp3_close(struct source *s) { drmp3_uninit(s->state); free(s->state); }
static size_t vorbis_read(struct source *s, short *out, size_t n)
{
    return (size_t)stb_vorbis_get_samples_short_interleaved(s->state, (int)s->channels, out, (int)(n * s->channels));
}
static void vorbis_close(struct source *s) { stb_vorbis_close(s->state); }

static int open_sampled(struct source *s, const char *path)
{
    switch (s->format) {
    case WAV: {
        drwav *w = malloc(sizeof *w);
        if (!w || !drwav_init_file(w, path, NULL)) { free(w); return 0; }
        s->state = w; s->rate = w->sampleRate; s->channels = w->channels; s->frames = w->totalPCMFrameCount;
        s->read = wav_read; s->close = wav_close;
        return 1;
    }
    case FLAC: {
        drflac *f = drflac_open_file(path, NULL);
        if (!f) return 0;
        s->state = f; s->rate = f->sampleRate; s->channels = f->channels; s->frames = f->totalPCMFrameCount;
        s->read = flac_read; s->close = flac_close;
        return 1;
    }
    case MP3: {
        drmp3 *m = malloc(sizeof *m);
        if (!m || !drmp3_init_file(m, path, NULL)) { free(m); return 0; }
        s->state = m; s->rate = m->sampleRate; s->channels = m->channels;
        s->frames = drmp3_get_pcm_frame_count(m);
        drmp3_seek_to_pcm_frame(m, 0);
        s->read = mp3_read; s->close = mp3_close;
        return 1;
    }
    case VORBIS: {
        int err = 0;
        stb_vorbis *v = stb_vorbis_open_filename(path, &err, NULL);
        stb_vorbis_info info;
        if (!v) return 0;
        info = stb_vorbis_get_info(v);
        s->state = v; s->rate = info.sample_rate; s->channels = (unsigned)info.channels;
        s->frames = stb_vorbis_stream_length_in_samples(v);
        s->read = vorbis_read; s->close = vorbis_close;
        return 1;
    }
    default:
        return 0;
    }
}

/* --- MIDI ---------------------------------------------------------------- */

struct midi {
    tsf *synth;
    midi_event *song, *at;
    double ms;              /* where playing has got to */
    double tail;            /* ms played after the last event */
};

static void send_event(tsf *t, const midi_event *m)
{
    switch (m->type) {
    case MIDI_PROGRAM_CHANGE: tsf_channel_set_presetnumber(t, m->channel, m->key, m->channel == 9); break;
    case MIDI_NOTE_ON: tsf_channel_note_on(t, m->channel, m->key, m->velocity / 127.0f); break;
    case MIDI_NOTE_OFF: tsf_channel_note_off(t, m->channel, m->key); break;
    case MIDI_PITCH_BEND: tsf_channel_set_pitchwheel(t, m->channel, m->pitch_bend); break;
    case MIDI_CONTROL_CHANGE: tsf_channel_midi_control(t, m->channel, m->key, m->velocity); break;
    default: break;
    }
}

static size_t midi_read(struct source *s, short *out, size_t n)
{
    struct midi *m = s->state;
    size_t done = 0;
    while (done < n) {
        size_t block = n - done < 64 ? n - done : 64;
        for (; m->at && m->at->time <= m->ms; m->at = m->at->next)
            send_event(m->synth, m->at);
        if (!m->at) {
            if (!tsf_active_voice_count(m->synth) || m->tail >= MIDI_TAIL_MS)
                break;
            m->tail += block * 1000.0 / MIDI_RATE;
        }
        tsf_render_short(m->synth, out + done * 2, (int)block, 0);
        m->ms += block * 1000.0 / MIDI_RATE;
        done += block;
    }
    return done;
}

static void midi_close(struct source *s)
{
    struct midi *m = s->state;
    tsf_close(m->synth);
    midi_free(m->song);
    free(m);
}

static int open_midi(struct source *s, const char *path)
{
    const char *font = getenv("SOUNDFONT");
    struct midi *m;
    midi_event *e;
    unsigned int length_ms = 0;
    if (!font || !*font)
        font = DEFAULT_SOUNDFONT;
    m = calloc(1, sizeof *m);
    if (!m) return 0;
    m->song = midi_load_file(path);
    if (!m->song) { free(m); return 0; }
    m->synth = tsf_load_filename(font);
    if (!m->synth) {
        printf("MUSIC: %s: MIDI plays through a SoundFont, and there is none at %s (SET SOUNDFONT= names one)\n",
               base_name(path), font);
        midi_free(m->song);
        free(m);
        return -1;
    }
    tsf_set_output(m->synth, TSF_STEREO_INTERLEAVED, MIDI_RATE, 0.0f);
    /* Decode every instrument the song plays before it starts, so no note
       waits for its samples: follow the program changes once. */
    for (e = m->song; e; e = e->next) {
        if (e->type == MIDI_PROGRAM_CHANGE)
            tsf_channel_set_presetnumber(m->synth, e->channel, e->key, e->channel == 9);
        else if (e->type == MIDI_NOTE_ON) {
            if (tsf_channel_get_preset_index(m->synth, e->channel) < 0)
                tsf_channel_set_presetnumber(m->synth, e->channel, 0, e->channel == 9);
            tsf_preload(m->synth, tsf_channel_get_preset_index(m->synth, e->channel), e->key, e->velocity / 127.0f);
        }
        length_ms = e->time;
    }
    tsf_reset(m->synth);
    tsf_channel_set_bank_preset(m->synth, 9, 128, 0);
    m->at = m->song;
    s->state = m; s->rate = MIDI_RATE; s->channels = 2;
    s->frames = (unsigned long long)length_ms * MIDI_RATE / 1000;
    s->read = midi_read; s->close = midi_close;
    return 1;
}

/* --- Playing -------------------------------------------------------------- */

static int play(const char *path)
{
    struct source s;
    short *buf, *two;
    size_t n;
    int opened;
    memset(&s, 0, sizeof s);
    s.format = sniff(path);
    if (s.format == UNKNOWN) {
        FILE *f = fopen(path, "rb");
        if (!f) { printf("MUSIC: %s: cannot open it\n", path); return 1; }
        fclose(f);
        printf("MUSIC: %s: not a WAV, FLAC, MP3, Ogg Vorbis or MIDI file\n", base_name(path));
        return 1;
    }
    opened = s.format == MIDI ? open_midi(&s, path) : open_sampled(&s, path);
    if (opened < 0)
        return 1;
    if (!opened) {
        printf("MUSIC: %s: cannot read it as %s%s\n", base_name(path), format_name[s.format],
               s.format == VORBIS ? " (Ogg Opus and FLAC-in-Ogg are not supported)" : "");
        return 1;
    }
    if (!s.channels || !s.rate) {
        printf("MUSIC: %s: no audio in it\n", base_name(path));
        s.close(&s);
        return 1;
    }
    if (freehold_sound_open((int)s.rate, s.channels == 1 ? 1 : 2) < 0) {
        printf("MUSIC: no sound device\n");
        s.close(&s);
        return 1;
    }
    printf("%s: %s, %u Hz, %s, %.1f s", base_name(path), format_name[s.format], s.rate,
           s.channels == 1 ? "mono" : "stereo", (double)s.frames / s.rate);
    if (s.channels > 2)
        printf(" (%u channels; the first two play)", s.channels);
    if (s.format == MIDI) {
        const char *font = getenv("SOUNDFONT");
        printf(" (SoundFont %s)", font && *font ? font : DEFAULT_SOUNDFONT);
    }
    printf("\n");
    fflush(stdout);
    buf = malloc((size_t)CHUNK * s.channels * sizeof(short));
    two = malloc((size_t)CHUNK * 2 * sizeof(short));
    if (!buf || !two) {
        printf("MUSIC: out of memory\n");
        free(buf); free(two);
        s.close(&s);
        freehold_sound_close();
        return 1;
    }
    while ((n = s.read(&s, buf, CHUNK)) > 0) {
        short *out = buf;
        if (s.channels > 2) {
            size_t i;
            for (i = 0; i < n; i++) {
                two[i * 2] = buf[i * s.channels];
                two[i * 2 + 1] = buf[i * s.channels + 1];
            }
            out = two;
        }
        freehold_sound_write(out, (int)(n * (s.channels == 1 ? 1 : 2) * sizeof(short)));
    }
    freehold_sound_drain();
    freehold_sound_close();
    free(buf);
    free(two);
    s.close(&s);
    return 0;
}

int main(int argc, char **argv)
{
    int i, failed = 0;
    if (argc < 2 || !strcmp(argv[1], "/?")) {
        printf("Plays music files: WAV, FLAC, MP3, Ogg Vorbis and MIDI.\n\n"
               "MUSIC file [file ...]\n\n"
               "MIDI files play through a SoundFont: SET SOUNDFONT=path names one;\n"
               "without it, %s.\n", DEFAULT_SOUNDFONT);
        return argc < 2;
    }
    for (i = 1; i < argc; i++)
        failed |= play(argv[i]);
    return failed;
}
