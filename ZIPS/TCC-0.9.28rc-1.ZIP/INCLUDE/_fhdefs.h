/* FREEHOLD C library: shared definitions (not a standard header). */
#ifndef _FHDEFS_H
#define _FHDEFS_H

#ifndef __SIZE_TYPE__
#define __SIZE_TYPE__ unsigned long long
#endif
#ifndef __PTRDIFF_TYPE__
#define __PTRDIFF_TYPE__ long long
#endif

#ifndef _SIZE_T_DEFINED
#define _SIZE_T_DEFINED
#endif

#ifndef NULL
#define NULL ((void *)0)
#endif

#ifdef __GNUC__
#define _FH_NORETURN __attribute__((noreturn))
#else
#define _FH_NORETURN __attribute__((noreturn))
#endif

typedef long long time_t;
typedef long clock_t;
typedef long long off_t;
typedef unsigned int mode_t;
typedef int pid_t;

#endif
