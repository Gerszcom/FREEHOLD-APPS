/* <assert.h> (FREEHOLD C library). Deliberately no include guard. */
#undef assert
#ifdef NDEBUG
#define assert(e) ((void)0)
#else
void _assert(const char *expr, const char *file, int line) __attribute__((noreturn));
#define assert(e) ((e) ? (void)0 : _assert(#e, __FILE__, __LINE__))
#endif
#if __STDC_VERSION__ >= 201112L && !defined static_assert
#define static_assert _Static_assert
#endif
