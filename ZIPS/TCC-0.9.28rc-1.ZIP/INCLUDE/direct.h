/* <direct.h> (FREEHOLD C library). */
#ifndef _DIRECT_H
#define _DIRECT_H

#include <unistd.h>
#include <sys/stat.h>

#define _mkdir(p) mkdir((p), 0777)
#define _rmdir rmdir
#define _chdir chdir
#define _getcwd getcwd

#endif
