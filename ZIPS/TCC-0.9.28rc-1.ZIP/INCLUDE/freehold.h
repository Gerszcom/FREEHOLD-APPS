/* <freehold.h>: what FREEHOLD offers C programs beyond standard C. */
#ifndef _FREEHOLD_H
#define _FREEHOLD_H

/* Graphics: enter a mode of at least w x h (the smallest the screen
   offers); 0 on success. Pixels are 32-bit 0x00RRGGBB, rows `stride`
   pixels apart; nothing shows until freehold_video_present. */
int freehold_video_enter(int w, int h);
void freehold_video_leave(void);
int freehold_video_width(void);
int freehold_video_height(void);
int freehold_video_stride(void);
unsigned int *freehold_video_pixels(void);
int freehold_video_present(int x, int y, int w, int h);

/* The console: raw input (keys as typed, no echo) and polling. */
void freehold_console_raw(int on);
int freehold_input_wait(unsigned int ms);
int freehold_input_read(char *buf, int n);

/* Key events, as a DOS game's INT 9 handler saw them: each key's
   scancode-set-1 byte, bit 7 set on a release, plus 0xE000 for an
   0xE0-prefixed key (0x1E: A pressed, 0x9E: released, 0xE048: cursor up
   pressed). freehold_key_event returns 0 when none is waiting. */
void freehold_key_events(int on);
int freehold_key_event(void);

/* Time. */
unsigned long long freehold_ticks_ms(void);
unsigned long long freehold_ticks_ns(void);
void freehold_sleep_ms(unsigned int ms);

/* Sound: one 16-bit stream per program, mixed with the others. */
int freehold_sound_rate(void);
int freehold_sound_open(int rate, int channels);
int freehold_sound_write(const void *samples, int bytes);
void freehold_sound_drain(void);
void freehold_sound_close(void);

#endif
