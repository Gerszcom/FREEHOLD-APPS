/* <io.h> (FREEHOLD C library): DOS compilers' low-level I/O names. */
#ifndef _IO_H
#define _IO_H

#include <unistd.h>
#include <fcntl.h>

int setmode(int fd, int mode);
#define _setmode setmode
#define _open open
#define _close close
#define _read read
#define _write write
#define _lseek lseek
#define _unlink unlink
#define _access access
#define _isatty isatty
#define _dup dup
#define _dup2 dup2

#endif
