/* <malloc.h> (FREEHOLD C library). */
#include <stdlib.h>
