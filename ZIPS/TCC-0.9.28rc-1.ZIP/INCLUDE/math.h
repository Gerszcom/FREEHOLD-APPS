/* <math.h> (FREEHOLD C library): the Rust toolchain's libm.
   long double is double (Windows x64). */
#ifndef _MATH_H
#define _MATH_H

typedef float float_t;
typedef double double_t;

#define HUGE_VAL (1e500)
#define HUGE_VALF (1e50f)
#define HUGE_VALL (1e500)
#define INFINITY (1e50f)
#define NAN (0.0f / 0.0f)

#define FP_NAN 0
#define FP_INFINITE 1
#define FP_ZERO 2
#define FP_SUBNORMAL 3
#define FP_NORMAL 4

int __fpclassify(double x);
int __fpclassifyf(float x);
int __signbit(double x);
int __signbitf(float x);
#define fpclassify(x) (sizeof(x) == sizeof(float) ? __fpclassifyf(x) : __fpclassify(x))
#define isnan(x) (fpclassify(x) == FP_NAN)
#define isinf(x) (fpclassify(x) == FP_INFINITE)
#define isfinite(x) (fpclassify(x) > FP_INFINITE)
#define isnormal(x) (fpclassify(x) == FP_NORMAL)
#define signbit(x) (sizeof(x) == sizeof(float) ? __signbitf(x) : __signbit(x))
#define isgreater(x, y) (!isnan(x) && !isnan(y) && (x) > (y))
#define isgreaterequal(x, y) (!isnan(x) && !isnan(y) && (x) >= (y))
#define isless(x, y) (!isnan(x) && !isnan(y) && (x) < (y))
#define islessequal(x, y) (!isnan(x) && !isnan(y) && (x) <= (y))
#define islessgreater(x, y) (!isnan(x) && !isnan(y) && (x) != (y))
#define isunordered(x, y) (isnan(x) || isnan(y))

#define M_E 2.7182818284590452354
#define M_LOG2E 1.4426950408889634074
#define M_LOG10E 0.43429448190325182765
#define M_LN2 0.69314718055994530942
#define M_LN10 2.30258509299404568402
#define M_PI 3.14159265358979323846
#define M_PI_2 1.57079632679489661923
#define M_PI_4 0.78539816339744830962
#define M_1_PI 0.31830988618379067154
#define M_2_PI 0.63661977236758134308
#define M_2_SQRTPI 1.12837916709551257390
#define M_SQRT2 1.41421356237309504880
#define M_SQRT1_2 0.70710678118654752440

#define _FH_MATH1(name) double name(double); float name##f(float); long double name##l(long double);
#define _FH_MATH2(name) double name(double, double); float name##f(float, float); long double name##l(long double, long double);
_FH_MATH1(acos) _FH_MATH1(asin) _FH_MATH1(atan) _FH_MATH1(acosh) _FH_MATH1(asinh) _FH_MATH1(atanh)
_FH_MATH1(cos) _FH_MATH1(sin) _FH_MATH1(tan) _FH_MATH1(cosh) _FH_MATH1(sinh) _FH_MATH1(tanh)
_FH_MATH1(exp) _FH_MATH1(exp2) _FH_MATH1(exp10) _FH_MATH1(expm1)
_FH_MATH1(log) _FH_MATH1(log2) _FH_MATH1(log10) _FH_MATH1(log1p)
_FH_MATH1(sqrt) _FH_MATH1(cbrt) _FH_MATH1(fabs) _FH_MATH1(floor) _FH_MATH1(ceil)
_FH_MATH1(round) _FH_MATH1(trunc) _FH_MATH1(rint) _FH_MATH1(erf) _FH_MATH1(erfc)
_FH_MATH1(tgamma) _FH_MATH1(lgamma)
_FH_MATH2(atan2) _FH_MATH2(pow) _FH_MATH2(fmod) _FH_MATH2(remainder) _FH_MATH2(hypot)
_FH_MATH2(fmin) _FH_MATH2(fmax) _FH_MATH2(fdim) _FH_MATH2(copysign) _FH_MATH2(nextafter)
#undef _FH_MATH1
#undef _FH_MATH2

double fma(double x, double y, double z);
float fmaf(float x, float y, float z);
#define fmal fma
double ldexp(double x, int e);
float ldexpf(float x, int e);
long double ldexpl(long double x, int e);
double scalbn(double x, int e);
float scalbnf(float x, int e);
#define scalbln(x, e) scalbn(x, (int)(e))
double frexp(double x, int *e);
float frexpf(float x, int *e);
long double frexpl(long double x, int *e);
double modf(double x, double *ip);
float modff(float x, float *ip);
long double modfl(long double x, long double *ip);
double remquo(double x, double y, int *q);
int ilogb(double x);
double logb(double x);
double nearbyint(double x);
long lround(double x);
long long llround(double x);
long lrint(double x);
long long llrint(double x);
double nan(const char *tag);
float nanf(const char *tag);

#endif
