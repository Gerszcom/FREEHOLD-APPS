/* <memory.h> (FREEHOLD C library). */
#include <string.h>
