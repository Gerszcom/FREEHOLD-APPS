/* midifile.h: read a Standard MIDI File into one list of timed events.

   FREEHOLD's own (D-098), under FREEHOLD's licence (MIT). One file, in the
   manner of the single-file libraries beside it in C:\TCC\INCLUDE:

       #define MIDIFILE_IMPLEMENTATION
       #include <midifile.h>

   in one C file, and plain #include <midifile.h> elsewhere.

   Formats 0, 1 and 2 (whose tracks are merged and play together); tempo
   changes and SMPTE time are applied, so each event carries its time in
   milliseconds from the start. Running status is understood; a note-on
   with velocity 0 is a note-off. System exclusive and meta events other
   than tempo are skipped. */

#ifndef MIDIFILE_H
#define MIDIFILE_H

#include <stddef.h>

enum midi_type {
    MIDI_NOTE_OFF = 0x80,
    MIDI_NOTE_ON = 0x90,
    MIDI_KEY_PRESSURE = 0xA0,
    MIDI_CONTROL_CHANGE = 0xB0,
    MIDI_PROGRAM_CHANGE = 0xC0,
    MIDI_CHANNEL_PRESSURE = 0xD0,
    MIDI_PITCH_BEND = 0xE0,
    MIDI_SET_TEMPO = 0x51          /* a meta event; `tempo` is set */
};

typedef struct midi_event {
    unsigned int time;          /* milliseconds from the start */
    unsigned char type;         /* enum midi_type */
    unsigned char channel;      /* 0..15 */
    unsigned char key;          /* note: key; control: controller; program: program; pressure: amount */
    unsigned char velocity;     /* note: velocity; control: value; key pressure: amount */
    unsigned short pitch_bend;  /* 0..16383, 8192 centred */
    unsigned int tempo;         /* MIDI_SET_TEMPO: microseconds a quarter note */
    struct midi_event *next;
} midi_event;

/* The events in time order, or NULL if the data is not a MIDI file (or
   memory ran out). midi_free frees the whole list. */
midi_event *midi_load_memory(const void *data, size_t size);
midi_event *midi_load_file(const char *path);
void midi_free(midi_event *events);
/* The time of the last event, in milliseconds. */
unsigned int midi_length_ms(const midi_event *events);

#endif

#ifdef MIDIFILE_IMPLEMENTATION
#ifndef MIDIFILE_IMPLEMENTED
#define MIDIFILE_IMPLEMENTED

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

struct midifile_track {
    const unsigned char *p, *end;
    unsigned long long tick;        /* of the event at p */
    unsigned char status;           /* running status */
    int done;
};

static unsigned int midifile_be32(const unsigned char *p)
{
    return ((unsigned int)p[0] << 24) | ((unsigned int)p[1] << 16) | ((unsigned int)p[2] << 8) | p[3];
}

/* A variable-length quantity; -1 past the end. */
static long midifile_vlq(struct midifile_track *t)
{
    unsigned long v = 0;
    int i;
    for (i = 0; i < 4; i++) {
        unsigned char b;
        if (t->p >= t->end)
            return -1;
        b = *t->p++;
        v = (v << 7) | (b & 0x7F);
        if (!(b & 0x80))
            return (long)v;
    }
    return -1;
}

/* Read the next delta time into t->tick, or mark the track done. */
static void midifile_next_delta(struct midifile_track *t)
{
    long d;
    if (t->done)
        return;
    d = midifile_vlq(t);
    if (d < 0)
        t->done = 1;
    else
        t->tick += (unsigned long)d;
}

/* Read one event at t->p into *e. Returns 1 for an event to keep, 0 for
   one to skip, -1 when the track ends. */
static int midifile_event(struct midifile_track *t, midi_event *e)
{
    unsigned char status;
    if (t->p >= t->end)
        return -1;
    status = *t->p;
    if (status & 0x80) {
        t->p++;
    } else {
        if (!(t->status & 0x80))
            return -1;              /* data with no status: broken */
        status = t->status;
    }
    if (status == 0xFF) {           /* meta */
        unsigned char type;
        long len;
        if (t->p >= t->end)
            return -1;
        type = *t->p++;
        len = midifile_vlq(t);
        if (len < 0 || len > t->end - t->p)
            return -1;
        if (type == 0x2F)
            return -1;              /* end of track */
        if (type == 0x51 && len == 3) {
            e->type = MIDI_SET_TEMPO;
            e->tempo = ((unsigned int)t->p[0] << 16) | ((unsigned int)t->p[1] << 8) | t->p[2];
            t->p += len;
            return 1;
        }
        t->p += len;
        return 0;
    }
    if (status == 0xF0 || status == 0xF7) {     /* system exclusive */
        long len = midifile_vlq(t);
        if (len < 0 || len > t->end - t->p)
            return -1;
        t->p += len;
        return 0;
    }
    if (status >= 0xF0)
        return -1;                  /* system common in a file: broken */
    t->status = status;
    e->type = status & 0xF0;
    e->channel = status & 0x0F;
    switch (e->type) {
    case MIDI_PROGRAM_CHANGE:
    case MIDI_CHANNEL_PRESSURE:
        if (t->p + 1 > t->end)
            return -1;
        e->key = t->p[0] & 0x7F;
        t->p += 1;
        return 1;
    default:
        if (t->p + 2 > t->end)
            return -1;
        e->key = t->p[0] & 0x7F;
        e->velocity = t->p[1] & 0x7F;
        t->p += 2;
        if (e->type == MIDI_PITCH_BEND)
            e->pitch_bend = (unsigned short)(e->key | (e->velocity << 7));
        if (e->type == MIDI_NOTE_ON && e->velocity == 0)
            e->type = MIDI_NOTE_OFF;
        return 1;
    }
}

midi_event *midi_load_memory(const void *data, size_t size)
{
    const unsigned char *p = data, *end = p + size;
    unsigned int format, ntracks, division, i, n = 0, cap = 0;
    struct midifile_track *tracks;
    midi_event *events = NULL;
    unsigned long long last_tick = 0;
    double ms = 0, ms_per_tick;
    unsigned int tempo = 500000;

    if (size < 14 || memcmp(p, "MThd", 4) || midifile_be32(p + 4) < 6)
        return NULL;
    format = (p[8] << 8) | p[9];
    ntracks = (p[10] << 8) | p[11];
    division = (p[12] << 8) | p[13];
    if (format > 2 || ntracks == 0 || division == 0)
        return NULL;
    p += 8 + midifile_be32(p + 4);
    tracks = calloc(ntracks, sizeof *tracks);
    if (!tracks)
        return NULL;
    for (i = 0; i < ntracks && p + 8 <= end; ) {
        unsigned int len = midifile_be32(p + 4);
        const unsigned char *body = p + 8;
        if ((size_t)(end - body) < len)
            len = (unsigned int)(end - body);   /* a short last track: read what is there */
        if (!memcmp(p, "MTrk", 4)) {
            tracks[i].p = body;
            tracks[i].end = body + len;
            midifile_next_delta(&tracks[i]);
            i++;
        }
        p = body + len;
    }
    ntracks = i;

    if (division & 0x8000) {        /* SMPTE: frames a second and ticks a frame */
        int fps = -(signed char)(division >> 8);
        ms_per_tick = 1000.0 / ((fps == 29 ? 29.97 : fps) * (division & 0xFF));
    } else {
        ms_per_tick = tempo / 1000.0 / division;
    }

    /* Merge the tracks in time order (by track at the same tick). */
    for (;;) {
        struct midifile_track *t = NULL;
        midi_event e;
        int r;
        for (i = 0; i < ntracks; i++)
            if (!tracks[i].done && (!t || tracks[i].tick < t->tick))
                t = &tracks[i];
        if (!t)
            break;
        memset(&e, 0, sizeof e);
        r = midifile_event(t, &e);
        if (r < 0) {
            t->done = 1;
            continue;
        }
        ms += (double)(t->tick - last_tick) * ms_per_tick;
        last_tick = t->tick;
        midifile_next_delta(t);
        if (!r)
            continue;
        if (e.type == MIDI_SET_TEMPO && !(division & 0x8000) && e.tempo) {
            tempo = e.tempo;
            ms_per_tick = tempo / 1000.0 / division;
        }
        if (n == cap) {
            midi_event *grown;
            cap = cap ? cap * 2 : 1024;
            grown = realloc(events, cap * sizeof *events);
            if (!grown) {
                free(events);
                free(tracks);
                return NULL;
            }
            events = grown;
        }
        e.time = (unsigned int)(ms + 0.5);
        events[n++] = e;
    }
    free(tracks);
    if (!n) {
        free(events);
        return NULL;
    }
    for (i = 0; i + 1 < n; i++)
        events[i].next = &events[i + 1];
    events[n - 1].next = NULL;
    return events;
}

midi_event *midi_load_file(const char *path)
{
    FILE *f = fopen(path, "rb");
    unsigned char *buf;
    long size;
    midi_event *events;
    if (!f)
        return NULL;
    if (fseek(f, 0, SEEK_END) || (size = ftell(f)) <= 0 || fseek(f, 0, SEEK_SET)) {
        fclose(f);
        return NULL;
    }
    buf = malloc((size_t)size);
    if (!buf || fread(buf, 1, (size_t)size, f) != (size_t)size) {
        free(buf);
        fclose(f);
        return NULL;
    }
    fclose(f);
    events = midi_load_memory(buf, (size_t)size);
    free(buf);
    return events;
}

void midi_free(midi_event *events)
{
    free(events);       /* one block: the list is an array */
}

unsigned int midi_length_ms(const midi_event *events)
{
    unsigned int t = 0;
    for (; events; events = events->next)
        t = events->time;
    return t;
}

#endif
#endif
