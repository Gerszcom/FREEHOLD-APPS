/* <process.h> (FREEHOLD C library): starting programs, as DOS compilers
   offered it. exec* runs the program and then ends with its exit code (no
   fork, no image replacement). */
#ifndef _PROCESS_H
#define _PROCESS_H

#define P_WAIT 0
#define P_NOWAIT 1
#define P_OVERLAY 2
#define _P_WAIT P_WAIT
#define _P_NOWAIT P_NOWAIT
#define _P_OVERLAY P_OVERLAY

long long spawnv(int mode, const char *path, char *const argv[]);
long long spawnvp(int mode, const char *file, char *const argv[]);
int execv(const char *path, char *const argv[]);
int execvp(const char *file, char *const argv[]);
long long cwait(int *status, long long pid, int action);
int getpid(void);
#define _spawnv spawnv
#define _spawnvp spawnvp
#define _execv execv
#define _execvp execvp
#define _cwait cwait

#endif
