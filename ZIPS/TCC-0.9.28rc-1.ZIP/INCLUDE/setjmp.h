/* <setjmp.h> (FREEHOLD C library): Windows x64 callee-saved state. */
#ifndef _SETJMP_H
#define _SETJMP_H

typedef unsigned long long jmp_buf[32];
typedef jmp_buf sigjmp_buf;

int setjmp(jmp_buf env);
int _setjmp(jmp_buf env);
void longjmp(jmp_buf env, int val) __attribute__((noreturn));
void _longjmp(jmp_buf env, int val) __attribute__((noreturn));
#define sigsetjmp(env, save) setjmp(env)
#define siglongjmp(env, val) longjmp(env, val)

#endif
