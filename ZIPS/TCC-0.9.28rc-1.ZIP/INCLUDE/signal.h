/* <signal.h> (FREEHOLD C library). Handlers run only through raise();
   Ctrl-C ends a FREEHOLD program and nothing else arrives from outside. */
#ifndef _SIGNAL_H
#define _SIGNAL_H

typedef int sig_atomic_t;
typedef void (*__sighandler_t)(int);

#define SIGINT 2
#define SIGILL 4
#define SIGFPE 8
#define SIGSEGV 11
#define SIGTERM 15
#define SIGBREAK 21
#define SIGABRT 22

#define SIG_DFL ((__sighandler_t)0)
#define SIG_IGN ((__sighandler_t)1)
#define SIG_ERR ((__sighandler_t)-1)

__sighandler_t signal(int sig, __sighandler_t handler);
int raise(int sig);

#endif
