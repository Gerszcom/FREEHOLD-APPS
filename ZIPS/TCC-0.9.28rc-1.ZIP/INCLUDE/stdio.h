/* <stdio.h> (FREEHOLD C library).
   Text mode is DOS's: a stream opened without "b" writes "\n" as "\r\n"
   and reads "\r\n" as "\n". stdin, stdout and stderr are text streams. */
#ifndef _STDIO_H
#define _STDIO_H

#include <stddef.h>
#include <stdarg.h>
#include <_fhdefs.h>

typedef struct _FILE FILE;
typedef long long fpos_t;

#define EOF (-1)
#define BUFSIZ 4096
#define FILENAME_MAX 260
#define FOPEN_MAX 20
#define L_tmpnam 260
#define TMP_MAX 32767
#define SEEK_SET 0
#define SEEK_CUR 1
#define SEEK_END 2
#define _IOFBF 0x0000
#define _IOLBF 0x0040
#define _IONBF 0x0004

extern FILE *stdin;
extern FILE *stdout;
extern FILE *stderr;

FILE *fopen(const char *path, const char *mode);
FILE *freopen(const char *path, const char *mode, FILE *f);
FILE *fdopen(int fd, const char *mode);
int fclose(FILE *f);
int fflush(FILE *f);
int setvbuf(FILE *f, char *buf, int mode, size_t size);
void setbuf(FILE *f, char *buf);
int fileno(FILE *f);
FILE *tmpfile(void);
char *tmpnam(char *buf);
FILE *popen(const char *command, const char *mode);
int pclose(FILE *f);
int remove(const char *path);
int rename(const char *old, const char *new_);

int fgetc(FILE *f);
int getc(FILE *f);
int getchar(void);
int ungetc(int c, FILE *f);
char *fgets(char *buf, int n, FILE *f);
ptrdiff_t getline(char **line, size_t *cap, FILE *f);
ptrdiff_t getdelim(char **line, size_t *cap, int delim, FILE *f);
int fputc(int c, FILE *f);
int putc(int c, FILE *f);
int putchar(int c);
int fputs(const char *s, FILE *f);
int puts(const char *s);

size_t fread(void *p, size_t size, size_t n, FILE *f);
size_t fwrite(const void *p, size_t size, size_t n, FILE *f);
int fseek(FILE *f, long off, int whence);
long ftell(FILE *f);
int fseeko(FILE *f, off_t off, int whence);
off_t ftello(FILE *f);
int _fseeki64(FILE *f, long long off, int whence);
long long _ftelli64(FILE *f);
void rewind(FILE *f);
int fgetpos(FILE *f, fpos_t *pos);
int fsetpos(FILE *f, const fpos_t *pos);
int feof(FILE *f);
int ferror(FILE *f);
void clearerr(FILE *f);
void perror(const char *s);

int printf(const char *fmt, ...);
int fprintf(FILE *f, const char *fmt, ...);
int sprintf(char *buf, const char *fmt, ...);
int snprintf(char *buf, size_t n, const char *fmt, ...);
int _snprintf(char *buf, size_t n, const char *fmt, ...);
int asprintf(char **out, const char *fmt, ...);
int vprintf(const char *fmt, va_list ap);
int vfprintf(FILE *f, const char *fmt, va_list ap);
int vsprintf(char *buf, const char *fmt, va_list ap);
int vsnprintf(char *buf, size_t n, const char *fmt, va_list ap);
int _vsnprintf(char *buf, size_t n, const char *fmt, va_list ap);
int vasprintf(char **out, const char *fmt, va_list ap);
int scanf(const char *fmt, ...);
int fscanf(FILE *f, const char *fmt, ...);
int sscanf(const char *s, const char *fmt, ...);
int vscanf(const char *fmt, va_list ap);
int vfscanf(FILE *f, const char *fmt, va_list ap);
int vsscanf(const char *s, const char *fmt, va_list ap);

#endif
