/* <stdlib.h> (FREEHOLD C library). */
#ifndef _STDLIB_H
#define _STDLIB_H

#include <stddef.h>
#include <_fhdefs.h>

#define EXIT_SUCCESS 0
#define EXIT_FAILURE 1
#define RAND_MAX 32767
#define MB_CUR_MAX 1

typedef struct { int quot, rem; } div_t;
typedef struct { long quot, rem; } ldiv_t;
typedef struct { long long quot, rem; } lldiv_t;

void *malloc(size_t size);
void *calloc(size_t n, size_t size);
void *realloc(void *p, size_t size);
void free(void *p);

void abort(void) _FH_NORETURN;
int atexit(void (*f)(void));
void exit(int code) _FH_NORETURN;
void _exit(int code) _FH_NORETURN;
void _Exit(int code) _FH_NORETURN;

char *getenv(const char *name);
int setenv(const char *name, const char *value, int overwrite);
int unsetenv(const char *name);
int putenv(const char *entry);
int system(const char *command);

void *bsearch(const void *key, const void *base, size_t n, size_t size, int (*cmp)(const void *, const void *));
void qsort(void *base, size_t n, size_t size, int (*cmp)(const void *, const void *));

int abs(int v);
long labs(long v);
long long llabs(long long v);
div_t div(int a, int b);
ldiv_t ldiv(long a, long b);
lldiv_t lldiv(long long a, long long b);

/* Multibyte characters: one byte each in the one locale, "C" (wchar.h). */
int mblen(const char *s, size_t n);
int mbtowc(wchar_t *pwc, const char *s, size_t n);
int wctomb(char *s, wchar_t wc);
size_t mbstowcs(wchar_t *d, const char *s, size_t n);
size_t wcstombs(char *d, const wchar_t *s, size_t n);

int rand(void);
void srand(unsigned int seed);

long strtol(const char *s, char **end, int base);
long long strtoll(const char *s, char **end, int base);
unsigned long strtoul(const char *s, char **end, int base);
unsigned long long strtoull(const char *s, char **end, int base);
double strtod(const char *s, char **end);
float strtof(const char *s, char **end);
long double strtold(const char *s, char **end);
int atoi(const char *s);
long atol(const char *s);
long long atoll(const char *s);
double atof(const char *s);

char *realpath(const char *path, char *resolved);
char *_fullpath(char *buf, const char *path, size_t size);

#endif
