/* <string.h> (FREEHOLD C library). */
#ifndef _STRING_H
#define _STRING_H

#include <stddef.h>

void *memcpy(void *dst, const void *src, size_t n);
void *memmove(void *dst, const void *src, size_t n);
void *memset(void *dst, int c, size_t n);
int memcmp(const void *a, const void *b, size_t n);
void *memchr(const void *s, int c, size_t n);

size_t strlen(const char *s);
size_t strnlen(const char *s, size_t max);
char *strcpy(char *dst, const char *src);
char *strncpy(char *dst, const char *src, size_t n);
size_t strlcpy(char *dst, const char *src, size_t size);
char *strcat(char *dst, const char *src);
char *strncat(char *dst, const char *src, size_t n);
int strcmp(const char *a, const char *b);
int strncmp(const char *a, const char *b, size_t n);
int strcoll(const char *a, const char *b);
size_t strxfrm(char *dst, const char *src, size_t n);
char *strchr(const char *s, int c);
char *strrchr(const char *s, int c);
char *strstr(const char *s, const char *find);
char *strcasestr(const char *s, const char *find);
size_t strspn(const char *s, const char *accept);
size_t strcspn(const char *s, const char *reject);
char *strpbrk(const char *s, const char *accept);
char *strtok(char *s, const char *delim);
char *strtok_r(char *s, const char *delim, char **save);
char *strdup(const char *s);
char *_strdup(const char *s);
char *strndup(const char *s, size_t n);
char *strerror(int e);

/* DOS compilers' extras. */
int stricmp(const char *a, const char *b);
int strnicmp(const char *a, const char *b, size_t n);
#define _stricmp stricmp
#define _strnicmp strnicmp
char *strupr(char *s);
char *strlwr(char *s);
#define _strupr strupr
#define _strlwr strlwr

#include <strings.h>

#endif
