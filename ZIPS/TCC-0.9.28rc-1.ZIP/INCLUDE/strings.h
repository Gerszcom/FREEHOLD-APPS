/* <strings.h> (FREEHOLD C library). */
#ifndef _STRINGS_H
#define _STRINGS_H

#include <stddef.h>

int strcasecmp(const char *a, const char *b);
int strncasecmp(const char *a, const char *b, size_t n);
void bzero(void *p, size_t n);
int bcmp(const void *a, const void *b, size_t n);

#endif
