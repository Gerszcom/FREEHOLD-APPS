/* <sys/types.h> (FREEHOLD C library). */
#ifndef _SYS_TYPES_H
#define _SYS_TYPES_H

#include <stddef.h>
#include <_fhdefs.h>

typedef unsigned int dev_t;
typedef unsigned int ino_t;
typedef unsigned int nlink_t;
typedef int uid_t;
typedef int gid_t;
typedef unsigned int useconds_t;
typedef long long blkcnt_t;
typedef unsigned int blksize_t;

#endif
