/* <sys/wait.h> (FREEHOLD C library). */
#ifndef _SYS_WAIT_H
#define _SYS_WAIT_H

#include <sys/types.h>

#define WNOHANG 1
#define WEXITSTATUS(s) (((s) >> 8) & 0xff)
#define WIFEXITED(s) 1
#define WIFSIGNALED(s) 0
#define WTERMSIG(s) 0

pid_t waitpid(pid_t pid, int *status, int options);

#endif
