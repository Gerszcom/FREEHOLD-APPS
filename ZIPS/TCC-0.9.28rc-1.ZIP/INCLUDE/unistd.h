/* <unistd.h> (FREEHOLD C library). */
#ifndef _UNISTD_H
#define _UNISTD_H

#include <sys/types.h>

#define STDIN_FILENO 0
#define STDOUT_FILENO 1
#define STDERR_FILENO 2
#ifndef SEEK_SET
#define SEEK_SET 0
#define SEEK_CUR 1
#define SEEK_END 2
#endif
#define F_OK 0
#define X_OK 0
#define W_OK 2
#define R_OK 4

extern char **environ;

int read(int fd, void *buf, unsigned int n);
int write(int fd, const void *buf, unsigned int n);
int close(int fd);
off_t lseek(int fd, off_t off, int whence);
long long lseek64(int fd, long long off, int whence);
int ftruncate(int fd, off_t len);
int dup(int fd);
int dup2(int fd, int target);
int isatty(int fd);
int unlink(const char *path);
int rmdir(const char *path);
int chdir(const char *path);
char *getcwd(char *buf, size_t size);
int access(const char *path, int mode);
int execv(const char *path, char *const argv[]);
int execvp(const char *file, char *const argv[]);
unsigned int sleep(unsigned int secs);
int usleep(useconds_t us);
pid_t getpid(void);
pid_t getppid(void);
uid_t getuid(void);
uid_t geteuid(void);
gid_t getgid(void);
gid_t getegid(void);

#endif
