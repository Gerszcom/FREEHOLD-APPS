/* <wchar.h> (FREEHOLD C library). One locale, "C": a multibyte character
   is one byte and its wide character the byte's value; wchar_t is 16 bits
   (Windows x64's ABI). A wide character above 255 has no multibyte form
   (EILSEQ). No wide stdio or wide formatting yet. */
#ifndef _WCHAR_H
#define _WCHAR_H

#include <stddef.h>
#include <_fhdefs.h>

typedef unsigned short wint_t;
typedef struct { int _state; } mbstate_t;

#define WEOF ((wint_t)0xFFFF)
#define WCHAR_MIN 0
#define WCHAR_MAX 0xFFFF

size_t wcslen(const wchar_t *s);
wchar_t *wcscpy(wchar_t *d, const wchar_t *s);
wchar_t *wcsncpy(wchar_t *d, const wchar_t *s, size_t n);
wchar_t *wcscat(wchar_t *d, const wchar_t *s);
int wcscmp(const wchar_t *a, const wchar_t *b);
int wcsncmp(const wchar_t *a, const wchar_t *b, size_t n);
wchar_t *wcschr(const wchar_t *s, wchar_t c);
wchar_t *wcsrchr(const wchar_t *s, wchar_t c);
wchar_t *wmemcpy(wchar_t *d, const wchar_t *s, size_t n);
wchar_t *wmemmove(wchar_t *d, const wchar_t *s, size_t n);
wchar_t *wmemset(wchar_t *d, wchar_t c, size_t n);
int wmemcmp(const wchar_t *a, const wchar_t *b, size_t n);
wchar_t *wmemchr(const wchar_t *s, wchar_t c, size_t n);

int mbsinit(const mbstate_t *ps);
size_t mbrlen(const char *s, size_t n, mbstate_t *ps);
size_t mbrtowc(wchar_t *pwc, const char *s, size_t n, mbstate_t *ps);
size_t wcrtomb(char *s, wchar_t wc, mbstate_t *ps);
size_t mbsrtowcs(wchar_t *d, const char **src, size_t len, mbstate_t *ps);
size_t wcsrtombs(char *d, const wchar_t **src, size_t len, mbstate_t *ps);
wint_t btowc(int c);
int wctob(wint_t c);

#endif
