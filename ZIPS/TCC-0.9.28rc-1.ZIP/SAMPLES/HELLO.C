/* HELLO.C: the Stage 13 gate's C program. It uses the C library broadly
   and prints one line per area; tools/gate.py checks each line. */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <setjmp.h>
#include <time.h>
#include <ctype.h>
#include <math.h>
#include <errno.h>

static jmp_buf back;

static void deep(int n)
{
    if (n == 0)
        longjmp(back, 7);
    deep(n - 1);
}

static int cmp_int(const void *a, const void *b)
{
    int x = *(const int *)a, y = *(const int *)b;
    return (x > y) - (x < y);
}

int main(int argc, char **argv)
{
    char buf[64], line[64], last[64];
    int i, n, lines;
    long sum;
    int *blocks[1000];
    int v[] = { 8, 3, 13, 1, 5, 2 };
    FILE *f;
    char *name;
    time_t now;
    char date[32];
    const char *comspec;

    printf("Hello from C on FREEHOLD\n");

    printf("printf: %d %d %x %x |%4s| %g %g %g\n", 42, -7, 42, 255, "hi",
           3.14159, 2.5e6, 0.125);

    strcpy(buf, "FREE");
    strcat(buf, "HOLD");
    printf("strings: %s %d cmp%s found=%s\n", buf, (int)strlen(buf),
           strcmp("abc", "abd") < 0 ? "<0" : ">=0", strstr(buf, "HOLD"));

    sum = 0;
    for (i = 0; i < 1000; i++) {
        blocks[i] = malloc(sizeof(int) * (1 + i % 17));
        if (!blocks[i]) {
            printf("malloc: failed at %d\n", i);
            return 1;
        }
        blocks[i][0] = i;
    }
    for (i = 0; i < 1000; i++) {
        sum += blocks[i][0];
        free(blocks[i]);
    }
    printf("malloc: %d blocks, sum %ld\n", i, sum);

    qsort(v, 6, sizeof v[0], cmp_int);
    printf("qsort:");
    for (i = 0; i < 6; i++)
        printf(" %d", v[i]);
    printf("\n");

    n = setjmp(back);
    if (n == 0)
        deep(10);
    printf("setjmp: came back with %d\n", n);

    name = tmpnam(NULL);
    f = fopen(name, "w");
    if (!f) {
        printf("file: cannot create %s: %s\n", name, strerror(errno));
        return 1;
    }
    fprintf(f, "first\nsecond\nthird\n");
    fclose(f);
    f = fopen(name, "r");
    lines = 0;
    last[0] = 0;
    while (fgets(line, sizeof line, f)) {
        line[strcspn(line, "\n")] = 0;
        strcpy(last, line);
        lines++;
    }
    fclose(f);
    remove(name);
    printf("file: wrote 3 lines, read %d lines, last '%s'\n", lines, last);

    now = time(NULL);
    strftime(date, sizeof date, "%Y-%m-%d %H:%M", localtime(&now));
    printf("time: %s\n", date);

    comspec = getenv("COMSPEC");
    printf("env: COMSPEC=%s\n", comspec ? comspec : "(none)");

    printf("argv: %d", argc);
    for (i = 1; i < argc; i++)
        printf(" [%s]", argv[i]);
    printf("\n");

    printf("math: %.4f %.4f %d\n", sqrt(2.0), atan2(1.0, 1.0) * 4, toupper('q'));
    return 0;
}
