/* TCC's configuration on FREEHOLD (ports/tcc, D-095). The target follows
   from __FREEHOLD__; the compiler's directory is C:\APPS\TCC, where GET installs it
   (aim 4, D-116). */
#define TCC_VERSION "0.9.28rc"
#define CONFIG_TCCDIR "C:/APPS/TCC"
#define CONFIG_TCC_STATIC 1
